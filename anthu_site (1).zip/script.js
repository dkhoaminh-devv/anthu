const imagesWrong = [
  "https://pin.it/BPLxT7E5E",
  "https://pin.it/4uokgXaBs",
  "https://pin.it/4VECDw7DG",
  "https://pin.it/6ExuoI0gw"
];
const nearFinal = "https://pin.it/55raP15gg";
const finalImg = "https://pin.it/1gVQI2Ij6";

const mainImg = document.getElementById('main-img');
const okeBtn = document.getElementById('okeBtn');
const wrongBtn = document.getElementById('wrongBtn');
const finalMsg = document.getElementById('finalMsg');
const audio = document.getElementById('bgAudio');
const audioToggle = document.getElementById('audioToggle');

let wrongIndex = 0;
let wrongScale = 1.0;
let okeScale = 1.0;

function tryPlayAudio(){
  audio.play().catch(()=>{
    audio.muted = true;
  });
}
tryPlayAudio();

audioToggle.addEventListener('click', () => {
  if(audio.paused){ audio.play(); audio.muted = false; audioToggle.textContent = '🔊'; }
  else { audio.pause(); audioToggle.textContent = '🔈'; }
});

wrongBtn.addEventListener('click', () => {
  if (wrongIndex < imagesWrong.length) {
    mainImg.src = imagesWrong[wrongIndex];
    wrongIndex++;
    wrongScale *= 0.85;
    okeScale *= 1.12;
    wrongBtn.style.transform = `scale(${wrongScale})`;
    okeBtn.style.transform = `scale(${okeScale})`;
    if (wrongIndex === imagesWrong.length) {
      wrongBtn.textContent = 'Tiếp theo...';
    }
  } else if (wrongIndex === imagesWrong.length) {
    mainImg.src = nearFinal;
    wrongIndex++;
    okeScale *= 2.6;
    okeBtn.style.transform = `scale(${okeScale})`;
    wrongBtn.style.opacity = 0;
    wrongBtn.style.pointerEvents = 'none';
    okeBtn.style.fontSize = '42px';
    okeBtn.style.padding = '26px 34px';
  } else {
    // nothing
  }
});

okeBtn.addEventListener('click', () => {
  mainImg.src = finalImg;
  finalMsg.hidden = false;
  okeBtn.style.transform = 'scale(1.8)';
  okeBtn.style.fontSize = '28px';
  audio.volume = 0.6;
});